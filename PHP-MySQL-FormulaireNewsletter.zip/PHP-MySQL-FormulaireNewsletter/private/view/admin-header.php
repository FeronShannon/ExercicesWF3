<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://use.fontawesome.com/c11c693658.js"></script>
    
	<title>CRUD Newsletter</title>
	<link href="https://fonts.googleapis.com/css?family=Oswald:400,600" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet">
	<link rel="stylesheet" href="assets/css/style.css" type="text/css" />
</head>
<body>
    <main>
        
        <div class="presentation">
            <p>Pour la mise en place du CRUD en PHP et MySQL j'ai utilisé :</p>
            <ul>
                <li>Un nom d'utilisateur.</li>
                <li>Et son email.</li>
            </ul>
        </div>
        <h1><a href="?">ADMIN Newsletter</a></h1>
    