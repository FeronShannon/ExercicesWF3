    
    </main>
    <footer>
        <p>&copy; Tous droits réservés / Shannon Féron.</p>
    </footer>
</body>
</html>